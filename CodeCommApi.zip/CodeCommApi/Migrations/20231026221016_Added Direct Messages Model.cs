﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CodeCommApi.Migrations
{
    /// <inheritdoc />
    public partial class AddedDirectMessagesModel : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "DirectMessages",
                columns: table => new
                {
                    MessageId = table.Column<Guid>(type: "TEXT", nullable: false),
                    MessageType = table.Column<int>(type: "INTEGER", nullable: false),
                    MessageBody = table.Column<string>(type: "TEXT", nullable: false),
                    MessageChatId = table.Column<Guid>(type: "TEXT", nullable: false),
                    MessageSenderId = table.Column<Guid>(type: "TEXT", nullable: false),
                    MessageReceiverId = table.Column<Guid>(type: "TEXT", nullable: false),
                    MessageSentTime = table.Column<DateTime>(type: "TEXT", nullable: false),
                    MessageTimeDelivered = table.Column<DateTime>(type: "TEXT", nullable: false),
                    MessageTimeSeen = table.Column<DateTime>(type: "TEXT", nullable: false),
                    MessageUpdatedAt = table.Column<DateTime>(type: "TEXT", nullable: false),
                    MessageIsDeleted = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DirectMessages", x => x.MessageId);
                    table.ForeignKey(
                        name: "FK_DirectMessages_Users_MessageReceiverId",
                        column: x => x.MessageReceiverId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DirectMessages_Users_MessageSenderId",
                        column: x => x.MessageSenderId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_DirectMessages_MessageReceiverId",
                table: "DirectMessages",
                column: "MessageReceiverId");

            migrationBuilder.CreateIndex(
                name: "IX_DirectMessages_MessageSenderId",
                table: "DirectMessages",
                column: "MessageSenderId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DirectMessages");
        }
    }
}
